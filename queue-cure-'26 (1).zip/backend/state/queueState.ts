/**
 * @file queueState.ts
 * @description In-memory store for the clinical queue.
 * This file maintains the patient list and settings in RAM (no database needed for MVP).
 * It includes helper functions to add patients, advance the queue, and retrieve statistics.
 */

// Define the patient's data structure
export interface Patient {
  token: string; // Formatting like T001, T002, etc.
  name: string;
  age?: number; // Optional age parameter
  gender?: string; // Optional gender parameter
  status: 'waiting' | 'in-consultation' | 'done';
  joinedAt: string; // ISO timestamp string
  doctorId?: string; // Optional assigned doctor ID
}

// In-memory data store variables
let queue: Patient[] = [];
let tokenCounter = 0; // Starts at 0, incremented during T-token generation
let avgConsultTime = 5; // Average consultation time per patient in minutes

/**
 * Formats a number to T00X format (e.g., 5 -> "T005", 12 -> "T012")
 */
function formatToken(num: number): string {
  return "T" + String(num).padStart(3, '0');
}

/**
 * Gets the current token that is actively in consultation
 */
export function getCurrentToken(): string | null {
  const current = queue.find(p => p.status === 'in-consultation');
  return current ? current.token : null;
}

/**
 * Calculates how many patients are currently waiting (status: 'waiting')
 */
export function getTotalWaiting(): number {
  return queue.filter(p => p.status === 'waiting').length;
}

/**
 * GET current queue summary
 */
export function getQueueSummary() {
  return {
    queue,
    currentToken: getCurrentToken(),
    totalWaiting: getTotalWaiting(),
    avgConsultTime,
  };
}

/**
 * Adds a new patient to the queue
 * Generates the token, appends the patient, and returns the patient object
 */
export function addPatient(name: string, age?: number, gender?: string, doctorId?: string): Patient {
  tokenCounter++;
  const newPatient: Patient = {
    token: formatToken(tokenCounter),
    name: name.trim(),
    age: age,
    gender: gender,
    status: 'waiting',
    joinedAt: new Date().toISOString(),
    doctorId: doctorId
  };
  queue.push(newPatient);
  return newPatient;
}

/**
 * Advances the queue:
 * - Marks the currently active 'in-consultation' patient as 'done'.
 * - Finds the next 'waiting' patient and changes their status to 'in-consultation'.
 * - Returns the newly called patient if any, or null if queue is empty.
 */
export function callNext(): { called: Patient | null; updatedQueue: Patient[] } {
  // 1. Move the current 'in-consultation' patient(s) to 'done'
  queue.forEach(p => {
    if (p.status === 'in-consultation') {
      p.status = 'done';
    }
  });

  // 2. Find the first patient who is waiting
  const nextPatient = queue.find(p => p.status === 'waiting');
  
  if (nextPatient) {
    nextPatient.status = 'in-consultation';
  }

  return {
    called: nextPatient || null,
    updatedQueue: queue
  };
}

/**
 * Updates the average consultation time setting
 */
export function updateAvgConsultTime(time: number): void {
  avgConsultTime = Math.max(1, time); // average time cannot be less than 1 minute
}

/**
 * Retrieves the average consultation time
 */
export function getAvgConsultTime(): number {
  return avgConsultTime;
}
