import { Router } from "express";
import { addPatient, getQueueSummary } from "../state/queueState";

const router = Router();

/**
 * POST /api/patients
 * @description Registers a new patient.
 * Generates their token, adds them to the live queue list, and broadcasts updates.
 */
router.post("/", (req, res) => {
  const { name, age, gender, doctorId } = req.body;

  if (!name || typeof name !== "string" || name.trim() === "") {
    return res.status(400).json({ error: "Patient name is required." });
  }

  let parsedAge: number | undefined;
  if (age !== undefined && age !== null && age !== "") {
    parsedAge = Number(age);
    if (isNaN(parsedAge) || parsedAge < 0) {
      return res.status(400).json({ error: "Patient age must be a positive number." });
    }
  }

  const parsedGender = typeof gender === "string" ? gender.trim() : undefined;
  const parsedDoctorId = typeof doctorId === "string" ? doctorId.trim() : undefined;

  // Add the patient to our state manager
  const newPatient = addPatient(name, parsedAge, parsedGender, parsedDoctorId);

  // Retrieve the Socket.io instance from Express App context
  const io = req.app.get("io");
  if (io) {
    // Broadcast the updated queue to all connected display screens and devices
    io.emit("queue-updated", getQueueSummary());
  }

  // Respond with the new patient details
  return res.status(201).json(newPatient);
});

export default router;
