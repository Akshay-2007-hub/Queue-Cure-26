import { Router } from "express";
import { updateAvgConsultTime, getAvgConsultTime, getQueueSummary } from "../state/queueState";

const router = Router();

/**
 * POST /api/settings
 * @description Updates settings like the average consultation time per patient (in minutes).
 */
router.post("/", (req, res) => {
  const { avgConsultTime } = req.body;
  const parsedTime = Number(avgConsultTime);

  if (isNaN(parsedTime) || parsedTime <= 0) {
    return res.status(400).json({ error: "Average consult time must be a number greater than 0." });
  }

  // Update in-memory state
  updateAvgConsultTime(parsedTime);

  const io = req.app.get("io");
  if (io) {
    // Broadcast setting changes
    io.emit("settings-updated", { avgConsultTime: parsedTime });
    // Also broadcast full queue summary with the updated estimate metrics
    io.emit("queue-updated", getQueueSummary());
  }

  return res.json({
    success: true,
    avgConsultTime: parsedTime,
  });
});

export default router;
