import { Router } from "express";
import { callNext, getQueueSummary } from "../state/queueState";

const router = Router();

/**
 * GET /api/queue
 * @description Returns the complete current state of the queue:
 * all items, the current token being served, and total count of waiting patients.
 */
router.get("/queue", (req, res) => {
  return res.json(getQueueSummary());
});

/**
 * POST /api/call-next
 * @description Advances the queue by marking the active patient as 'done'
 * and calling the next waiting patient 'in-consultation'.
 * Broadcasts socket events to update receptionist screens and waiting room TVs.
 */
router.post("/call-next", (req, res) => {
  const result = callNext();
  const summary = getQueueSummary();

  const io = req.app.get("io");
  if (io) {
    // 1. Broadcast updated queue lists so receptionist and patients see the live list
    io.emit("queue-updated", summary);

    // 2. Broadcast a dedicated 'token-called' event to announce the specific token
    if (result.called) {
      io.emit("token-called", {
        token: result.called.token,
        name: result.called.name,
      });
    }
  }

  return res.json({
    called: result.called,
    summary,
  });
});

export default router;
