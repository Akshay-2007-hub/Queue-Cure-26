/**
 * @file backend/server.js
 * @description Express + Socket.io server startup script (hackathon submission replica).
 * This script binds express and socket.io together, registers routes, and handles
 * real-time client state updates.
 */

import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";

// Router imports
import patientsRouter from "./routes/patients.js";
import queueRouter from "./routes/queue.js";
import settingsRouter from "./routes/settings.js";
import { getQueueSummary } from "./state/queueState.js";

// Initialize Express, HTTP, and Socket.io
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*", // allow access from any domain or development origin
    methods: ["GET", "POST"]
  }
});

// Store ws 'io' instance in Express so REST routes can emit socket updates
app.set("io", io);

// standard body parsing and CORS middlewares
app.use(cors());
app.use(express.json());

// API Registrations (Rest endpoints)
app.use("/api/patients", patientsRouter);
app.use("/api", queueRouter); // matches GET /api/queue & POST /api/call-next
app.use("/api/settings", settingsRouter);

// Sync socket connections!
io.on("connection", (socket) => {
  console.log(`Lounge Screen / Admin connected: ${socket.id}`);
  
  // Instant initial sync to newly connected clients
  socket.emit("queue-updated", getQueueSummary());

  socket.on("disconnect", () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

const PORT = 3000;
httpServer.listen(PORT, () => {
  console.log(`Backend Server booted successfully on port ${PORT}`);
});
