import React, { useState } from "react";
import { Search, Clock, UserCheck, AlertCircle } from "lucide-react";
import { Patient } from "./QueueList.tsx";
import { getDoctorById } from "../doctorsData";

interface WaitEstimateProps {
  patients: Patient[];
  avgConsultTime: number; // in minutes
  id?: string;
}

/**
 * WaitEstimate allows patients to check their specific queuing progress.
 * Calculations:
 * - If status is 'in-consultation' -> Called / Serving Now (0 mins)
 * - If status is 'done' -> Completed / Visited
 * - If status is 'waiting' -> Indices ahead of them in the waiting list x avgConsultTime
 */
export const WaitEstimate: React.FC<WaitEstimateProps> = ({ patients, avgConsultTime, id }) => {
  const [queryToken, setQueryToken] = useState("");
  const [isChecked, setIsChecked] = useState(false);
  const [result, setResult] = useState<{
    found: boolean;
    patient?: Patient;
    position?: number; // how many are currently ahead
    minutesAhead?: number;
  } | null>(null);

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    setIsChecked(true);

    const formattedQuery = queryToken.trim().toUpperCase();
    if (!formattedQuery) {
      setResult(null);
      return;
    }

    const patient = patients.find(
      (p) => p.token.toUpperCase() === formattedQuery
    );

    if (!patient) {
      setResult({ found: false });
      return;
    }

    if (patient.status === "done") {
      setResult({ found: true, patient, position: 0, minutesAhead: 0 });
      return;
    }

    if (patient.status === "in-consultation") {
      setResult({ found: true, patient, position: 0, minutesAhead: 0 });
      return;
    }

    // For 'waiting' patient, find their exact order within all 'waiting' patients
    const waitingList = patients.filter((p) => p.status === "waiting");
    const myIndex = waitingList.findIndex((p) => p.token === patient.token);

    // Number of people ahead is exactly their index (e.g. index 0 means 0 people ahead of you)
    const position = myIndex >= 0 ? myIndex : 0;
    const minutesAhead = position * avgConsultTime;

    setResult({
      found: true,
      patient,
      position,
      minutesAhead,
    });
  };

  return (
    <div id={id} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5 select-none text-sans">
      <div className="space-y-1">
        <h4 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
          <svg
            viewBox="0 0 100 100"
            className="w-4 h-4 text-teal-600 fill-current shrink-0"
            aria-hidden="true"
          >
            {/* Head */}
            <circle cx="50" cy="20" r="10" />
            {/* Left Arm */}
            <rect x="27" y="35" width="8" height="28" rx="4" />
            {/* Right Arm */}
            <rect x="65" y="35" width="8" height="28" rx="4" />
            {/* Torso */}
            <path d="M37,41 A6,6 0 0,1 43,35 H57 A6,6 0 0,1 63,41 V56 H37 Z" />
            {/* Left Leg */}
            <rect x="37" y="52" width="11" height="34" rx="5.5" />
            {/* Right Leg */}
            <rect x="52" y="52" width="11" height="34" rx="5.5" />
          </svg>
          Personal Token Tracker
        </h4>
        <p className="text-xs text-slate-400 font-sans leading-relaxed">
          Wondering how long until it's your turn? Check your physical token or SMS index below.
        </p>
      </div>

      {/* Query input form */}
      <form onSubmit={handleLookup} className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm placeholder:text-slate-400 focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all font-mono font-medium"
            placeholder="e.g. T003"
            value={queryToken}
            onChange={(e) => {
              setQueryToken(e.target.value);
              setIsChecked(false);
              setResult(null);
            }}
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-450 font-sans text-xs font-bold uppercase tracking-wider">
            Code
          </span>
        </div>
        <button
          type="submit"
          className="cursor-pointer bg-slate-900 hover:bg-slate-850 text-white px-5 py-3 rounded-xl text-sm font-bold font-sans flex items-center gap-1.5 transition-all active:scale-95 shadow-sm"
        >
          <Search size={14} />
          <span>Track</span>
        </button>
      </form>

      {/* Lookup calculation displays */}
      {isChecked && result && (
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-150 font-sans transition-all duration-300">
          {!result.found ? (
            <div className="flex gap-2.5 items-start text-slate-900">
              <AlertCircle className="text-rose-500 shrink-0 mt-0.5" size={16} />
              <div>
                <p className="text-xs font-bold text-rose-700">Token Not Found</p>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed font-medium">
                  Verify the code on your coupon ticket (e.g. <strong>T001</strong>). If it persists, confirm with the receptionist desk.
                </p>
              </div>
            </div>
          ) : result.patient?.status === "done" ? (
            <div className="flex gap-2.5 items-start">
              <UserCheck className="text-slate-500 shrink-0 mt-0.5" size={16} />
              <div>
                <p className="text-xs font-bold text-slate-700">Consultation Completed</p>
                <p className="text-[11px] text-slate-500 mt-0.5 font-medium">
                  This token <strong>{result.patient.token}</strong> was already checked out by the consultant.
                </p>
              </div>
            </div>
          ) : result.patient?.status === "in-consultation" ? (
            <div className="space-y-2.5">
              <div className="flex gap-2 items-center text-emerald-700">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
                <p className="text-xs font-bold uppercase tracking-wider">Now Serving!</p>
              </div>
              <p className="text-sm font-bold text-slate-850">
                Token {result.patient.token} is in the Consultation Room.
              </p>
              {(() => {
                const doc = getDoctorById(result.patient.doctorId);
                return doc ? (
                  <p className="text-xs text-emerald-800 font-bold bg-emerald-100/50 px-2.5 py-1.5 rounded-lg border border-emerald-150/50">
                    Consulting: {doc.name} ({doc.specialization})
                  </p>
                ) : null;
              })()}
              <p className="text-xs text-slate-500 font-medium">
                Please proceed inside or alert the attendant near the entrance.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Patient</p>
                  <p className="text-xs font-bold text-slate-800 capitalize">{result.patient?.name}</p>
                  {(() => {
                    const doc = getDoctorById(result.patient?.doctorId);
                    return doc ? (
                      <p className="text-[10px] text-teal-800 font-bold bg-teal-55/70 px-2 py-0.5 rounded border border-teal-200/50 mt-1 inline-block select-none">
                        {doc.specialization} &bull; {doc.name}
                      </p>
                    ) : null;
                  })()}
                </div>
                <div className="text-right">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Token</p>
                  <p className="text-xs font-mono font-bold text-amber-600">{result.patient?.token}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white p-3 rounded-xl border border-slate-150 relative overflow-hidden shadow-xs">
                  <p className="text-[10px] uppercase text-slate-400 font-bold mb-0.5">People Ahead</p>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-black text-slate-800">{result.position}</span>
                    <span className="text-[10px] text-slate-450 font-semibold">Patients</span>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-150 relative overflow-hidden shadow-xs">
                  <p className="text-[10px] uppercase text-slate-400 font-bold mb-0.5">Estimated Wait</p>
                  <div className="flex items-baseline gap-1 text-emerald-600 font-bold">
                    <Clock size={11} className="text-emerald-500 shrink-0 self-center" />
                    <span className="text-xl font-black">{result.minutesAhead}</span>
                    <span className="text-[10px] text-slate-450 font-semibold">Minutes</span>
                  </div>
                </div>
              </div>
              
              <div className="text-[10px] text-slate-450 bg-slate-120/40 p-2 rounded-lg text-center font-semibold font-sans">
                Estimates assume ~{avgConsultTime}m per person. This may vary depending on patient clinical needs.
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
