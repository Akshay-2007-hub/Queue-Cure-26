import React from "react";
import { Users, Clock, CheckCircle } from "lucide-react";
import { getDoctorById } from "../doctorsData";

// Matches patient shape
export interface Patient {
  token: string;
  name: string;
  age?: number;
  gender?: string;
  status: "waiting" | "in-consultation" | "done";
  joinedAt: string;
  doctorId?: string;
}

interface QueueListProps {
  patients: Patient[];
  id?: string;
}

/**
 * QueueList renders a beautiful Bento-themed grid list of patients.
 * Uses exact colors, spacing, borders, and layouts from the Bento Design instructions.
 */
export const QueueList: React.FC<QueueListProps> = ({ patients, id }) => {
  if (patients.length === 0) {
    return (
      <div id={id} className="text-center py-12 bg-white rounded-3xl border border-slate-200 shadow-sm text-slate-400 font-sans space-y-2">
        <Users className="mx-auto text-slate-300 stroke-[1.5]" size={36} />
        <p className="font-bold text-sm text-slate-700">The clinic queue is currently empty.</p>
        <p className="text-xs text-slate-450">Add a patient to generate their bento coupon.</p>
      </div>
    );
  }

  return (
    <div id={id} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col overflow-hidden">
      {/* Header and Legend */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">Live Patient List</h2>
        <div className="flex flex-wrap gap-2 text-[10px] font-bold">
          <span className="flex items-center gap-1 bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">CONSULTING</span>
          <span className="flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">WAITING</span>
          <span className="flex items-center gap-1 bg-slate-105 bg-slate-120 text-slate-500 px-2 py-0.5 rounded-full">DONE</span>
        </div>
      </div>

      {/* Grid wrapper */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {patients.map((patient) => {
          const doc = getDoctorById(patient.doctorId);

          if (patient.status === "in-consultation") {
            return (
              <div 
                key={patient.token}
                className="bg-emerald-50 border border-emerald-150 rounded-2xl p-4 flex flex-col justify-between min-h-[110px] h-auto shadow-xs transition-transform hover:scale-[1.01]"
              >
                <div className="flex justify-between items-start">
                  <span className="text-2xl font-black font-mono tracking-tight text-emerald-800">{patient.token}</span>
                  <span className="text-[9px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-md uppercase tracking-wider">Serving</span>
                </div>
                <div className="space-y-1 mt-1.5">
                  <p className="text-sm font-bold text-emerald-950 truncate flex items-baseline gap-1" title={patient.name}>
                    <span className="capitalize truncate">{patient.name}</span>
                    {(patient.age !== undefined && patient.age !== null || patient.gender) && (
                      <span className="text-xs font-medium text-emerald-800 shrink-0">
                        ({[patient.age !== undefined && patient.age !== null ? `${patient.age} yrs` : "", patient.gender].filter(Boolean).join(" • ")})
                      </span>
                    )}
                  </p>
                  {doc && (
                    <div className="text-[10px] font-bold text-emerald-800 flex items-center">
                      <span className="bg-emerald-150/60 px-1.5 py-0.5 rounded-md text-[10px] text-emerald-900 border border-emerald-200/50 truncate max-w-full">
                        {doc.specialization} &bull; {doc.name}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          } else if (patient.status === "waiting") {
            return (
              <div 
                key={patient.token}
                className="bg-amber-50 border border-amber-150 rounded-2xl p-4 flex flex-col justify-between min-h-[110px] h-auto shadow-xs transition-transform hover:scale-[1.01]"
              >
                <div className="flex justify-between items-start">
                  <span className="text-2xl font-black font-mono tracking-tight text-amber-800">{patient.token}</span>
                  <span className="text-[9px] font-bold bg-amber-550 text-white px-2 py-0.5 rounded-md uppercase tracking-wider">Waiting</span>
                </div>
                <div className="space-y-1 mt-1.5">
                  <p className="text-sm font-bold text-amber-950 truncate flex items-baseline gap-1" title={patient.name}>
                    <span className="capitalize truncate">{patient.name}</span>
                    {(patient.age !== undefined && patient.age !== null || patient.gender) && (
                      <span className="text-xs font-medium text-amber-800 shrink-0">
                        ({[patient.age !== undefined && patient.age !== null ? `${patient.age} yrs` : "", patient.gender].filter(Boolean).join(" • ")})
                      </span>
                    )}
                  </p>
                  {doc && (
                    <div className="text-[10px] font-bold text-amber-800 flex items-center">
                      <span className="bg-amber-150/60 px-1.5 py-0.5 rounded-md text-[10px] text-amber-900 border border-amber-200/50 truncate max-w-full">
                        {doc.specialization} &bull; {doc.name}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          } else {
            return (
              <div 
                key={patient.token}
                className="bg-slate-50 border border-slate-150 rounded-2xl p-4 flex flex-col justify-between min-h-[110px] h-auto opacity-70 transition-transform hover:scale-[1.01]"
              >
                <div className="flex justify-between items-start">
                  <span className="text-2xl font-black font-mono tracking-tight text-slate-500">{patient.token}</span>
                  <span className="text-[9px] font-bold bg-slate-200 text-slate-600 px-2 py-0.5 rounded-md uppercase tracking-wider">Done</span>
                </div>
                <div className="space-y-1 mt-1.5">
                  <p className="text-sm font-semibold text-slate-700 truncate line-through flex items-baseline gap-1" title={patient.name}>
                    <span className="capitalize truncate">{patient.name}</span>
                    {(patient.age !== undefined && patient.age !== null || patient.gender) && (
                      <span className="text-xs font-medium text-slate-500 shrink-0 no-underline">
                        ({[patient.age !== undefined && patient.age !== null ? `${patient.age} yrs` : "", patient.gender].filter(Boolean).join(" • ")})
                      </span>
                    )}
                  </p>
                  {doc && (
                    <div className="text-[10px] font-semibold text-slate-500 flex items-center">
                      <span className="bg-slate-100 px-1.5 py-0.5 rounded-md text-[9px] text-slate-600 border border-slate-200 truncate max-w-full">
                        {doc.specialization} &bull; {doc.name}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          }
        })}
      </div>
    </div>
  );
};
