import React, { useState } from "react";
import { UserPlus } from "lucide-react";
import { DOCTORS } from "../doctorsData";

interface PatientFormProps {
  onAddPatient: (name: string, age?: number, gender?: string, doctorId?: string) => Promise<void> | void;
  id?: string;
}

/**
 * PatientForm handles inputting new patients into the receptionist dashboard.
 * Designed with a clean layout and explicit placeholder guidelines.
 */
export const PatientForm: React.FC<PatientFormProps> = ({ onAddPatient, id }) => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [selectedDoctorId, setSelectedDoctorId] = useState(DOCTORS[0]?.id || "");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError("Please enter a valid patient name.");
      return;
    }

    let parsedAge: number | undefined;
    if (age.trim() !== "") {
      parsedAge = Number(age.trim());
      if (isNaN(parsedAge) || parsedAge < 0 || parsedAge > 130) {
        setError("Please enter a valid age between 0 and 130.");
        return;
      }
    }

    try {
      setIsSubmitting(true);
      await onAddPatient(trimmedName, parsedAge, gender || undefined, selectedDoctorId || undefined);
      setName(""); // Reset form on success
      setAge("");
      setGender("");
      if (DOCTORS[0]) {
        setSelectedDoctorId(DOCTORS[0].id);
      }
    } catch (err: any) {
      setError(err.message || "Something went wrong registering patient.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form id={id} onSubmit={handleSubmit} className="space-y-4">
      {/* Patient Name Input */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="patient-name" className="text-xs font-bold text-slate-500 uppercase ml-1 tracking-wider">
          Patient Name
        </label>
        <div className="relative">
          <input
            id="patient-name"
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm placeholder:text-slate-400 focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all font-sans font-medium"
            placeholder="Enter Patient Name..."
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              if (error) setError("");
            }}
            disabled={isSubmitting}
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">
            <UserPlus size={16} />
          </span>
        </div>
      </div>

      {/* Patient Age Input */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="patient-age" className="text-xs font-bold text-slate-500 uppercase ml-1 tracking-wider">
          Patient Age (optional)
        </label>
        <div className="relative">
          <input
            id="patient-age"
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm placeholder:text-slate-400 focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all font-sans font-medium"
            placeholder="Enter Patient Age (e.g. 28)..."
            value={age}
            onChange={(e) => {
              // Only allow digits or empty value
              const val = e.target.value;
              if (/^\d*$/.test(val)) {
                setAge(val);
                if (error) setError("");
              }
            }}
            disabled={isSubmitting}
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
            yrs
          </span>
        </div>
      </div>

      {/* Patient Gender Input */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-bold text-slate-500 uppercase ml-1 tracking-wider">
          Patient Gender (optional)
        </label>
        <div className="grid grid-cols-4 gap-2">
          {["Unspecified", "Male", "Female", "Other"].map((option) => {
            const isSelected = (gender === "" && option === "Unspecified") || (gender === option);
            return (
              <button
                key={option}
                type="button"
                onClick={() => setGender(option === "Unspecified" ? "" : option)}
                className={`py-2.5 px-1 text-xs font-bold rounded-xl border transition-all text-center cursor-pointer ${
                  isSelected
                    ? "bg-teal-50 border-teal-500 text-teal-700 font-extrabold shadow-sm"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:border-slate-300"
                }`}
                disabled={isSubmitting}
              >
                {option}
              </button>
            );
          })}
        </div>
      </div>

      {/* Doctor/Specialist Selection */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="patient-doctor" className="text-xs font-bold text-slate-500 uppercase ml-1 tracking-wider">
          Consulting Doctor & Specialty
        </label>
        <div className="relative">
          <select
            id="patient-doctor"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all font-sans font-medium appearance-none cursor-pointer text-slate-700 focus:bg-white"
            value={selectedDoctorId}
            onChange={(e) => setSelectedDoctorId(e.target.value)}
            disabled={isSubmitting}
          >
            {DOCTORS.map((doc) => (
              <option key={doc.id} value={doc.id}>
                {doc.name} • {doc.specialization} {doc.availableToday ? "(Available Today)" : "(Away Today - Back Soon)"}
              </option>
            ))}
          </select>
          <span className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </span>
        </div>
      </div>

      {error && <span className="text-xs font-semibold text-rose-600 ml-1 block">{error}</span>}

      <button
        id={`${id || "add-patient"}-btn`}
        type="submit"
        disabled={isSubmitting}
        className="w-full flex items-center justify-center gap-2 cursor-pointer bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-xs disabled:opacity-55 disabled:active:scale-100 font-sans transition-all text-sm"
      >
        {isSubmitting ? (
          <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        ) : (
          <UserPlus size={16} />
        )}
        <span>{isSubmitting ? "Generating Token..." : "Add to Queue"}</span>
      </button>
    </form>
  );
};
