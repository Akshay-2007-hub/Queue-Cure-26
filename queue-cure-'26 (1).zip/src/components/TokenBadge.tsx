import React from "react";

interface TokenBadgeProps {
  token: string;
  status: "waiting" | "in-consultation" | "done";
  size?: "sm" | "md" | "lg";
  id?: string;
}

/**
 * TokenBadge component renders a styled pill showing the token number and status color.
 * Colors:
 * - waiting: Amber/Yellow (attention/waiting)
 * - in-consultation: Green (active/serving)
 * - done: Gray (completed)
 */
export const TokenBadge: React.FC<TokenBadgeProps> = ({ token, status, size = "md", id }) => {
  // Select color palettes based on the status
  const badgeColors = {
    waiting: "bg-amber-50 text-amber-700 border-amber-200 ring-amber-500/10",
    "in-consultation": "bg-emerald-50 text-emerald-700 border-emerald-200 ring-emerald-500/10 animate-pulse",
    done: "bg-slate-100 text-slate-500 border-slate-200 ring-slate-500/5",
  };

  // Human readable label for assistive tech or micro-badges
  const statusLabel = {
    waiting: "Waiting",
    "in-consultation": "In Cabinet",
    done: "Checked Out",
  };

  const currentColors = badgeColors[status] || badgeColors.waiting;
  const currentLabel = statusLabel[status] || "Waiting";

  // Compute text sizes
  const sizes = {
    sm: "px-2 py-0.5 text-xs font-semibold rounded-full border",
    md: "px-2.5 py-1 text-sm font-semibold rounded-full border shadow-sm",
    lg: "px-6 py-3 text-3xl font-black rounded-2xl border-2 tracking-wider shadow-md",
  };

  return (
    <div id={id} className={`inline-flex items-center gap-1.5 ${sizes[size]} ${currentColors} font-mono transition-all duration-300`}>
      {/* Small dot indicator */}
      <span className={`h-1.5 w-1.5 rounded-full ${
        status === "in-consultation" ? "bg-emerald-500" :
        status === "waiting" ? "bg-amber-500" : "bg-slate-400"
      }`} />
      <span>{token}</span>
      {size === "sm" && (
        <span className="text-[10px] uppercase font-sans text-opacity-80">
          ({currentLabel})
        </span>
      )}
    </div>
  );
};
