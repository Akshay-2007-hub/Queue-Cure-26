// Doctor interface for type-safety
export interface Doctor {
  id: string;
  name: string;
  specialization: "Cardiology" | "Pediatrics" | "Dermatology" | "Orthopedics" | "Family Medicine";
  qualification: string;
  experience: string;
  timings: string;
  days: string[];
  bio: string;
  imageSeed: string;
  availableToday: boolean;
}

export const DOCTORS: Doctor[] = [
  {
    id: "doc1",
    name: "Dr. Sarah Jenkins",
    specialization: "Cardiology",
    qualification: "MD, FACC - Harvard Medical School",
    experience: "14+ Years",
    timings: "09:00 AM - 02:00 PM",
    days: ["Monday", "Wednesday", "Friday"],
    bio: "Specializes in preventive cardiology, cardiac imaging, and advanced cardiac care diagnostics.",
    imageSeed: "doc_sarah",
    availableToday: true
  },
  {
    id: "doc2",
    name: "Dr. Marcus Vance",
    specialization: "Pediatrics",
    qualification: "MD, FAAP - Johns Hopkins University",
    experience: "12+ Years",
    timings: "08:00 AM - 04:00 PM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    bio: "Dedicated to holistic pediatric development, immunizations, and newborn care counseling.",
    imageSeed: "doc_marcus",
    availableToday: true
  },
  {
    id: "doc3",
    name: "Dr. Elena Rostova",
    specialization: "Dermatology",
    qualification: "MD - Stanford School of Medicine",
    experience: "10+ Years",
    timings: "10:00 AM - 06:00 PM",
    days: ["Tuesday", "Thursday", "Saturday"],
    bio: "Expertise in clinical dermatology, skin cancer screenings, and non-invasive medical aesthetics.",
    imageSeed: "doc_elena",
    availableToday: false
  },
  {
    id: "doc4",
    name: "Dr. Amit Patel",
    specialization: "Orthopedics",
    qualification: "MS, MCh (Orth) - King's College London",
    experience: "16+ Years",
    timings: "02:00 PM - 08:00 PM",
    days: ["Monday", "Tuesday", "Thursday"],
    bio: "Specializes in joint reconstructive therapeutics, sports medicine, and minimally invasive bone repair.",
    imageSeed: "doc_amit",
    availableToday: false
  },
  {
    id: "doc5",
    name: "Dr. Chloe Sterling",
    specialization: "Family Medicine",
    qualification: "MD - Yale School of Medicine",
    experience: "8+ Years",
    timings: "09:00 AM - 05:00 PM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    bio: "Focused on comprehensive family healthcare, chronic illness management, and lifestyle medicine.",
    imageSeed: "doc_chloe",
    availableToday: true
  }
];

export function getDoctorById(id?: string): Doctor | undefined {
  if (!id) return undefined;
  return DOCTORS.find(d => d.id === id);
}

export function getDoctorBySpecialization(spec?: string): Doctor | undefined {
  if (!spec) return undefined;
  return DOCTORS.find(d => d.specialization.toLowerCase() === spec.toLowerCase());
}
