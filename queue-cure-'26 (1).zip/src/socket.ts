/**
 * @file socket.ts
 * @description Real-time WebSocket connection singleton for the frontend.
 * By calling io() with no parameters, it automatically connects to the same host/port 
 * that serves the client application (making it compatible with both local development
 * and containerized hosting).
 */

import { io, Socket } from "socket.io-client";

// Initialize socket connection to the current host origin
export const socket: Socket = io({
  autoConnect: true,
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 5000,
});

// For easier client debugging
socket.on("connect", () => {
  console.log("WebSocket connected to server with ID:", socket.id);
});

socket.on("disconnect", () => {
  console.log("WebSocket disconnected from server");
});
