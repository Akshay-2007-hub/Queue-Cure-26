import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Link } from "react-router-dom";
import logoImg from "./hospital.png";
import {
  Clock,
  Phone,
  MapPin,
  Stethoscope,
  Heart,
  Baby,
  Smile,
  Activity,
  Award,
  Users,
  ShieldCheck,
  Calendar,
  ChevronRight,
  Sparkles,
  ExternalLink
} from "lucide-react";

const CLINIC_HOURS = [
  { days: "Monday - Friday", hours: "08:00 AM - 08:00 PM", isWeek: true },
  { days: "Saturday", hours: "08:00 AM - 05:00 PM", isWeek: true },
  { days: "Sunday", hours: "09:00 AM - 01:00 PM (Urgent Care Only)", isWeek: false }
];

// Specialization Department details for visual presentation
interface SpecialtyDept {
  name: string;
  count: number;
  description: string;
  details: string;
  colorClass: string;
  icon: React.ReactNode;
}

export function HomePage() {
  const [currentDay, setCurrentDay] = useState<string>("");
  const [currentTimeText, setCurrentTimeText] = useState<string>("");
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [copyFeedback, setCopyFeedback] = useState<string>("");
  const [directionFeedback, setDirectionFeedback] = useState<string>("");

  // Determine if clinic is currently open
  useEffect(() => {
    const updateTimeStatus = () => {
      const now = new Date();
      const daysOfWeek = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ];
      const dayName = daysOfWeek[now.getDay()];
      setCurrentDay(dayName);

      const hours = now.getHours();
      const minutes = now.getMinutes();
      const timeVal = hours + minutes / 60;

      // Simple schedule logic for standard visual feedback
      let openStatus = false;
      if (dayName === "Sunday") {
        openStatus = timeVal >= 9 && timeVal < 13;
      } else if (dayName === "Saturday") {
        openStatus = timeVal >= 8 && timeVal < 17;
      } else {
        openStatus = timeVal >= 8 && timeVal < 20;
      }

      setIsOpen(openStatus);
      
      // Formatted AM/PM clock in IST (Asia/Kolkata)
      const formattedTime = now.toLocaleTimeString("en-IN", {
        timeZone: "Asia/Kolkata",
        hour: "numeric",
        minute: "2-digit",
        hour12: true
      });
      const formattedDay = now.toLocaleDateString("en-IN", {
        timeZone: "Asia/Kolkata",
        weekday: "long"
      });
      setCurrentTimeText(`${formattedDay}, ${formattedTime}`);
    };

    updateTimeStatus();
    const interval = setInterval(updateTimeStatus, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText("+91 98800 12345");
    setCopyFeedback("Phone number copied!");
    setTimeout(() => setCopyFeedback(""), 3000);
  };

  const handleDirectionsClick = () => {
    navigator.clipboard.writeText("12, Khader Nawaz Khan Road, Nungambakkam, Chennai, Tamil Nadu - 600006");
    setDirectionFeedback("Address Copied! (Chennai)");
    setTimeout(() => setDirectionFeedback(""), 3000);
  };

  const departments: SpecialtyDept[] = [
    {
      name: "Cardiology",
      count: 2,
      description: "Advanced diagnostic heart screens & preventative circulatory therapies.",
      details: "Preventive cardiology, ECG scans, cardiovascular health assessments.",
      colorClass: "bg-red-50 text-red-650 border-red-200/50",
      icon: <Heart size={20} className="text-red-500" />
    },
    {
      name: "Pediatrics",
      count: 3,
      description: "Holistic, gentle pediatric growth monitoring, therapy, & newborn immunizations.",
      details: "Wellness exams, pediatric triage, pain-free youth clinical counseling.",
      colorClass: "bg-amber-50 text-amber-650 border-amber-200/50",
      icon: <Baby size={20} className="text-amber-500" />
    },
    {
      name: "Dermatology",
      count: 2,
      description: "Full-cycle clinical skincare, medical dermatology screenings, & treatments.",
      details: "Acne treatments, custom allergy panels, non-invasive skin aesthetics.",
      colorClass: "bg-pink-50 text-pink-650 border-pink-200/50",
      icon: <Smile size={20} className="text-pink-500" />
    },
    {
      name: "Orthopedics",
      count: 1,
      description: "Joint reconstructive diagnostics, alignment, and modern orthopedic therapies.",
      details: "Bone therapy care, joint comfort metrics, ligament diagnostics.",
      colorClass: "bg-emerald-50 text-emerald-650 border-emerald-200/50",
      icon: <Activity size={20} className="text-emerald-500" />
    },
    {
      name: "Family Medicine",
      count: 4,
      description: "Comprehensive multi-generational medical consultations & custom lifestyle solutions.",
      details: "Chronic wellness oversight, routine checkups, nutrition diagnostics.",
      colorClass: "bg-blue-50 text-blue-650 border-blue-200/50",
      icon: <Users size={20} className="text-blue-500" />
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans pb-24">
      {/* Upper Brand Info Highlight Banner */}
      <div className="bg-gradient-to-r from-teal-900 to-slate-900 text-white text-[11px] font-mono tracking-wider font-semibold py-2.5 px-4 text-center flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-6 shadow-sm border-b border-teal-800/30">
        <span className="flex items-center gap-1.5">
          <Activity size={12} className="text-teal-400 animate-pulse" />
          <span>REAL-TIME DIGITAL CLINIC SERVICES DEPLOYED</span>
        </span>
        <span className="hidden sm:inline text-teal-600">|</span>
        <span className="flex items-center gap-1.5">
          <Clock size={12} className="text-teal-400" />
          <span>Time (IST): <strong className="text-emerald-300">{currentTimeText || "Retrieving..."}</strong></span>
        </span>
        <span className="hidden sm:inline text-teal-600">|</span>
        <span className="flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${isOpen ? "bg-emerald-400" : "bg-amber-400 animate-ping"}`} />
          <span>Clinic Status: <strong className={isOpen ? "text-emerald-400" : "text-amber-300"}>{isOpen ? "OPEN NOW" : "RECEPTION CLOSED"}</strong></span>
        </span>
      </div>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-6">
        
        {/* Clinic Header (Bento Styled) with Official Logo */}
        <header id="clinic-home-header" className="bg-white border border-slate-200/80 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden shadow-xs border border-slate-200 shrink-0">
              <img
                src={logoImg}
                alt="Queue Cure Clinic Logo"
                className="object-cover w-full h-full"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 font-sans">Queue Cure Clinic</h1>
              <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Multi-Specialty Diagnostics &amp; Queue Management</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <Link
              to="/doctors"
              className="text-xs font-bold text-slate-600 hover:text-teal-600 px-3.5 py-2 rounded-xl hover:bg-slate-50 border border-slate-200/40 transition-all"
            >
              Doctor Directory
            </Link>
            <Link
              to="/waiting"
              className="text-xs font-bold text-slate-650 hover:text-teal-650 px-3.5 py-2 rounded-xl hover:bg-teal-50/40 border border-teal-100/60 transition-all"
            >
              Live Waiting Lounge
            </Link>
            <Link
              to="/receptionist"
              className="text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 px-4 py-2 rounded-xl transition-all shadow-xs"
            >
              Reception Admin
            </Link>
          </div>
        </header>

        {/* Hero Section */}
        <section className="bg-white rounded-3xl shadow-sm border border-slate-200/60 overflow-hidden mb-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 sm:p-10 items-center">
            
            {/* Left Hand: Hero Welcome / Copy */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-50 border border-teal-200/50 rounded-full text-teal-800 text-xs font-bold shadow-xs">
                <Sparkles size={13} className="text-teal-600" />
                <span>Premier Patient Care Solutions</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 leading-tight tracking-tight">
                Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-emerald-600">Queue Cure Clinic</span>
              </h1>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
                We are a state-of-the-art diagnostic and family healthcare clinic dedicated to providing comfortable medical consultations, patient queue visibility, and professional clinical staff operations. We utilize a real-time digital ticket tracker so you can enjoy your wait safely in our lounge or surroundings.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3 pt-2">
                <Link
                  to="/waiting"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-sm transition-all focus:ring-4 focus:ring-slate-300 shadow-md group cursor-pointer"
                >
                  <span>View Live waiting lounge</span>
                  <ChevronRight size={16} className="text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                </Link>
                <Link
                  to="/receptionist"
                  className="inline-flex items-center gap-2 px-5 py-3.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-2xl text-sm transition-all shadow-xs cursor-pointer"
                >
                  <span>Reception Desk Control</span>
                  <ExternalLink size={14} className="text-slate-400" />
                </Link>
              </div>

              {/* Stat Pillars */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-100">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="text-2xl font-extrabold text-slate-800">15+</div>
                  <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Expert Specialists</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="text-2xl font-extrabold text-slate-800">100%</div>
                  <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Queue Visibility</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="text-2xl font-extrabold text-slate-800">25k+</div>
                  <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Patients Served</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="text-2xl font-extrabold text-slate-800">24/7</div>
                  <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Urgent Support</div>
                </div>
              </div>
            </div>

            {/* Right Hand: Interactive Brand Identity Showcase */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center bg-slate-50 rounded-2xl p-6 border border-slate-100 relative group overflow-hidden h-full">
              <div className="absolute top-3 left-3 bg-white/85 px-2.5 py-1 rounded-lg text-[10px] font-mono border border-slate-200/50 text-slate-500 font-bold">
                ESTABLISHED 2026
              </div>
              
              {/* Generated Logo Frame */}
              <div className="relative p-2 bg-white rounded-2xl shadow-sm border border-slate-200/80 max-w-[210px] aspect-square flex items-center justify-center overflow-hidden mb-5">
                <img
                  src={logoImg}
                  alt="Queue Cure Clinic Logo"
                  className="object-cover w-full h-full rounded-xl transition-all"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="text-center">
                <h3 className="text-md font-extrabold text-slate-800">Official Clinic Logo</h3>
                <p className="text-[11px] text-slate-500 max-w-sm mt-1">
                  Symbolizes efficient healthcare workflow, clinical care, and patient queue restoration.
                </p>
              </div>

              {/* Mini Contact Pill */}
              <div className="mt-5 w-full bg-white p-3.5 rounded-xl border border-slate-200/50 shadow-2xs flex items-center justify-between gap-3 text-left">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="bg-teal-50 text-teal-600 p-2 rounded-lg shrink-0">
                    <Phone size={14} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider leading-none">Emergency Line</p>
                    <p className="text-xs font-bold text-slate-800 truncate">+91 98800 12345</p>
                  </div>
                </div>
                <button
                  onClick={handleCopyPhone}
                  className="bg-slate-50 border border-slate-200 hover:bg-slate-100 py-1.5 px-3 rounded-lg text-[10px] font-bold text-slate-600 cursor-pointer transition-all shrink-0 active:scale-95"
                >
                  {copyFeedback || "Copy Call"}
                </button>
              </div>
            </div>
            
          </div>
        </section>

        {/* Informative Two Column Core Section: Working Timings & Clinic Flow */}
        <section className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-12">
          
          {/* Detailed Timings Block (5 Column) */}
          <div className="md:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/60 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                  <Clock size={20} />
                </div>
                <div>
                  <h2 className="text-lg font-extrabold text-slate-900">Hospital Working Hours</h2>
                  <p className="text-xs text-slate-500">Scheduled outpatient departments & emergency triage</p>
                </div>
              </div>

              <div className="space-y-3.5 pt-2">
                {CLINIC_HOURS.map((sched, index) => {
                  const isCurrentDay = currentDay.includes(sched.days.split(" ")[0]) || 
                                      (sched.days.includes("Monday") && ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].includes(currentDay));
                  return (
                    <div
                      key={index}
                      className={`p-3.5 rounded-xl border flex justify-between items-center transition-all ${
                        isCurrentDay 
                          ? "bg-slate-900 border-slate-900 text-white shadow-xs" 
                          : "bg-slate-50 border-slate-100 text-slate-700"
                      }`}
                    >
                      <div className="space-y-0.5">
                        <p className={`text-xs font-bold ${isCurrentDay ? "text-teal-300" : "text-slate-500 font-semibold"}`}>
                          {sched.days} {isCurrentDay && "• Today"}
                        </p>
                        <p className={`text-sm font-extrabold ${isCurrentDay ? "text-white" : "text-slate-800"}`}>{sched.hours}</p>
                      </div>
                      <div className={`text-[10px] font-bold py-1 px-2.5 rounded-md ${
                        isCurrentDay 
                          ? "bg-teal-500/20 text-teal-300 border border-teal-500/30" 
                          : "bg-slate-200/50 text-slate-600"
                      }`}>
                        {sched.isWeek ? "Daily OPD" : "Triage Only"}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 pt-5 border-t border-slate-100 flex items-start gap-3">
              <ShieldCheck size={18} className="text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-slate-700">Admitting Policy</p>
                <p className="text-[11px] text-slate-500 leading-relaxed mt-0.5">
                  Walk-in registrations take place at the front reception desk during the hours listed above. Please obtain your digital ticket to track your turn on the digital queue monitor.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Clinic Facilities & Layout Details (7 Column) */}
          <div className="md:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/60 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                  <Stethoscope size={20} />
                </div>
                <div>
                  <h2 className="text-lg font-extrabold text-slate-900">Hospital Facilities & Logistics</h2>
                  <p className="text-xs text-slate-500">Fully equipped medical ecosystem & healthcare logistics</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex gap-3.5">
                  <div className="bg-white text-emerald-600 h-10 w-10 shrink-0 shadow-sm border border-slate-100 rounded-xl flex items-center justify-center">
                    <Heart size={18} />
                  </div>
                  <div className="space-y-1 min-w-0">
                    <h3 className="text-xs font-extrabold text-slate-800">Advanced Diagnostic Labs</h3>
                    <p className="text-[11px] font-medium text-slate-500 leading-normal">
                      Equipped with blood panels, urine diagnostics, ultra-sound screening, and modern digital electrocardiograms.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex gap-3.5">
                  <div className="bg-white text-blue-600 h-10 w-10 shrink-0 shadow-sm border border-slate-100 rounded-xl flex items-center justify-center">
                    <Baby size={18} />
                  </div>
                  <div className="space-y-1 min-w-0">
                    <h3 className="text-xs font-extrabold text-slate-800">Pediatric & Child Care Unit</h3>
                    <p className="text-[11px] font-medium text-slate-500 leading-normal">
                      A dedicated child-friendly screening lounge designed to reduce clinic anxiety and offer painless care routines.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex gap-3.5">
                  <div className="bg-white text-amber-600 h-10 w-10 shrink-0 shadow-sm border border-slate-100 rounded-xl flex items-center justify-center">
                    <Activity size={18} />
                  </div>
                  <div className="space-y-1 min-w-0">
                    <h3 className="text-xs font-extrabold text-slate-800">Digital Queue Tracker</h3>
                    <p className="text-[11px] font-medium text-slate-500 leading-normal">
                      Real-time wait telemetry calculating average consultation speed so patients can wait comfortably without standing-room-only stress.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex gap-3.5">
                  <div className="bg-white text-slate-600 h-10 w-10 shrink-0 shadow-sm border border-slate-100 rounded-xl flex items-center justify-center">
                    <MapPin size={18} />
                  </div>
                  <div className="space-y-1 min-w-0">
                    <h3 className="text-xs font-extrabold text-slate-800">Transit & Accessibility</h3>
                    <p className="text-[11px] font-medium text-slate-500 leading-normal">
                      Convenient municipal parking desk, wheelchair-accessible patient elevators, and drop-off driveway lanes at our front desk.
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* Address bar */}
            <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="flex items-center gap-2">
                <MapPin size={14} className="text-teal-600 shrink-0" />
                <span className="text-[11px] font-bold text-slate-600">12, Khader Nawaz Khan Road, Nungambakkam, Chennai, Tamil Nadu - 600006</span>
              </div>
              <button
                onClick={handleDirectionsClick}
                className="text-[10px] text-teal-600 font-extrabold uppercase tracking-wider hover:text-teal-750 cursor-pointer shrink-0 transition-all active:scale-95"
              >
                {directionFeedback || "Directions Link ↗"}
              </button>
            </div>
          </div>

        </section>

        {/* Clinical Specialty Departments Overview */}
        <section className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200 pb-5 gap-3">
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Clinical Specialty Departments</h2>
              <p className="text-xs text-slate-500 mt-1">
                Explore our fully-equipped, modern clinical departments overseen by leading medical experts.
              </p>
            </div>
            
            <Link
              to="/doctors"
              className="inline-flex items-center gap-1.5 bg-slate-950 hover:bg-slate-800 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl shadow-xs cursor-pointer transition-all shrink-0 font-sans"
            >
              <span>View Specialists Directory</span>
              <ChevronRight size={14} className="text-slate-400" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {departments.map((dept, idx) => (
              <motion.div
                key={dept.name}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className="bg-white rounded-2xl p-5 border border-slate-205/90 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className={`h-11 w-11 rounded-xl border flex items-center justify-center shrink-0 ${dept.colorClass}`}>
                      {dept.icon}
                    </div>
                    <div>
                      <h3 className="text-sm font-extrabold text-slate-905">{dept.name}</h3>
                      <span className="text-[10px] font-bold text-teal-705 bg-teal-50 px-1.5 py-0.5 rounded-md border border-teal-200/30 font-mono">
                        {dept.count} SPECIALIST(S) ACTIVE
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                    {dept.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-between items-center bg-white">
                  <span className="text-[10px] text-slate-450 font-bold max-w-[170px] truncate">{dept.details}</span>
                  <Link
                    to="/doctors"
                    className="text-[11px] text-teal-650 font-extrabold hover:text-teal-750 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Meet Doctors</span>
                    <ChevronRight size={12} />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Patient Register Flow Helper Section */}
        <section className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 mb-6 mt-12 border border-slate-800 shadow-sm flex flex-col lg:flex-row justify-between items-center gap-8">
          <div className="space-y-3.5 max-w-2xl text-center lg:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 border border-white/15 rounded-full text-white text-xs font-semibold">
              <Sparkles size={13} className="text-emerald-400" />
              <span>Queue Cure Live Ecosystem</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-extrabold">Ready to Register & Monitor Your Ticket Live?</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              If you are at the clinic or arriving soon, please proceed to the receptionist tab to generate an appointment token. Track live updates, token highlights, average consultation periods, and screen announcements instantly without physical hassle.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto text-center shrink-0">
            <Link
              to="/receptionist"
              className="py-3 px-5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold rounded-xl text-center text-xs transition-colors shadow-sm cursor-pointer"
            >
              Add New Patient Ticket
            </Link>
            <Link
              to="/waiting"
              className="py-3 px-5 bg-white/10 hover:bg-white/20 border border-white/15 text-white font-extrabold rounded-xl text-center text-xs transition-all cursor-pointer"
            >
              Open Digital Lounge Monitor
            </Link>
          </div>
        </section>

      </main>
    </div>
  );
}
