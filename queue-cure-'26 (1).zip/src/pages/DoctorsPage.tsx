import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Link } from "react-router-dom";
import logoImg from "./hospital.png";
import {
  Stethoscope,
  ChevronRight,
  Heart,
  Baby,
  Smile,
  ShieldCheck,
  Calendar,
  Sparkles,
  Award,
  Search,
  Filter,
  ArrowLeft,
  Clock,
  UserCheck
} from "lucide-react";

import { Doctor, DOCTORS } from "../doctorsData";

export function DoctorsPage() {
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showAvailableOnly, setShowAvailableOnly] = useState<boolean>(false);

  const specialtyCategories = ["All", "Cardiology", "Pediatrics", "Dermatology", "Orthopedics", "Family Medicine"];

  // Filter logic including search and availability
  const filteredDoctors = DOCTORS.filter((doc) => {
    const matchesSpecialty = selectedSpecialty === "All" || doc.specialization === selectedSpecialty;
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          doc.specialization.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          doc.qualification.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAvailability = !showAvailableOnly || doc.availableToday;
    
    return matchesSpecialty && matchesSearch && matchesAvailability;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans pb-24">
      {/* Top Banner Navigation Row */}
      <div className="bg-white border-b border-slate-200/60 sticky top-0 z-40 shadow-xs font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col sm:flex-row justify-between items-center gap-3.5">
          <div className="flex items-center gap-3">
            <Link to="/" className="w-8 h-8 rounded-lg overflow-hidden border border-slate-200 shrink-0 select-none">
              <img
                src={logoImg}
                alt="Queue Cure Clinic Logo"
                className="object-cover w-full h-full"
                referrerPolicy="no-referrer"
              />
            </Link>
            <div className="flex flex-col">
              <span className="text-xs font-extrabold text-slate-800">Queue Cure Clinic</span>
              <span className="text-[10px] text-slate-400 font-medium">Doctor Directory Map</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 font-semibold transition-all group shrink-0"
            >
              <ArrowLeft size={14} className="group-hover:-translate-x-0.5 transition-transform" />
              <span>Back to Hospital Home</span>
            </Link>
            <span className="text-slate-200 hidden sm:inline">|</span>
            <span className="text-xs text-teal-600 font-mono font-bold tracking-wider hidden sm:inline">BOARD-CERTIFIED MED-STAFF</span>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* Banner Section */}
        <section className="bg-gradient-to-r from-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-teal-850 shadow-sm relative overflow-hidden mb-10">
          <div className="absolute right-0 bottom-0 top-0 w-1/3 opacity-10 bg-radial pointer-events-none" />
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 border border-white/15 rounded-full text-white text-xs font-semibold">
              <Sparkles size={13} className="text-teal-400" />
              <span>Meet Our Clinicians</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Hospital Doctors &amp; Specialization Directory
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Consult with board-certified physicians, surgeon leads, and family general practitioners. Verify scheduled outpatient slot hours, weekly availability, and proceed to book or join the real-time queue.
            </p>
          </div>
        </section>

        {/* Filters and Search Bar Section */}
        <section className="bg-white rounded-3xl border border-slate-200/60 shadow-xs p-5 mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center">
            
            {/* Search Input Box */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search doctors by name, credentials, or department..."
                className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-sm pl-10 pr-4 py-2.5 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all font-medium placeholder-slate-400"
              />
            </div>

            {/* Checkbox Filter for Available Only */}
            <div className="flex items-center gap-2.5 px-1 md:self-center">
              <input
                type="checkbox"
                id="availOnly"
                checked={showAvailableOnly}
                onChange={(e) => setShowAvailableOnly(e.target.checked)}
                className="w-4 h-4 rounded-sm border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
              />
              <label htmlFor="availOnly" className="text-xs font-bold text-slate-700 cursor-pointer select-none flex items-center gap-1.5">
                <UserCheck size={14} className="text-teal-600" />
                <span>Show Available Today Only</span>
              </label>
            </div>

          </div>

          {/* Specialty Categories Selection */}
          <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 shrink-0">
              <Filter size={12} />
              <span>Department Specialty</span>
            </span>
            
            <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto max-w-full">
              {specialtyCategories.map((spec) => {
                const isActive = selectedSpecialty === spec;
                return (
                  <button
                    key={spec}
                    onClick={() => setSelectedSpecialty(spec)}
                    className={`py-1.5 px-3 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer select-none ${
                      isActive
                        ? "bg-slate-900 border border-slate-900 text-white shadow-xs"
                        : "bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100"
                    }`}
                  >
                    {spec}
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* Doctor Profiles Grid */}
        <section className="space-y-6">
          <div className="flex justify-between items-center text-xs text-slate-500 font-bold uppercase tracking-wider px-1">
            <span>Result Count: {filteredDoctors.length} Clinician(s)</span>
            <span>All credentials verified</span>
          </div>

          {filteredDoctors.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDoctors.map((doc, idx) => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                  className="bg-white rounded-2xl p-5 border border-slate-205/85 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-4">
                    {/* Header line */}
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex items-center gap-3">
                        <div className={`h-11 w-11 rounded-xl text-white font-extrabold flex items-center justify-center shadow-inner shrink-0 ${
                          doc.specialization === "Cardiology" ? "bg-red-500 animate-pulse" :
                          doc.specialization === "Pediatrics" ? "bg-amber-500" :
                          doc.specialization === "Dermatology" ? "bg-pink-500" :
                          doc.specialization === "Orthopedics" ? "bg-teal-500" : "bg-blue-500"
                        }`}>
                          {doc.name.split(" ").slice(-1)[0].substring(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <h3 className="text-sm font-extrabold text-slate-900 truncate">{doc.name}</h3>
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide px-1.5 py-0.5 bg-slate-100 rounded-md inline-block">
                            {doc.specialization}
                          </span>
                        </div>
                      </div>

                      <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full border shrink-0 ${
                        doc.availableToday 
                          ? "bg-emerald-50 border-emerald-250 text-emerald-700 font-sans" 
                          : "bg-slate-100 border-slate-200 text-slate-500"
                      }`}>
                        {doc.availableToday ? "Available Today" : "Not In Today"}
                      </span>
                    </div>

                    {/* Qualifications & Biographics */}
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5">
                        <Award size={13} className="text-teal-600 shrink-0" />
                        <p className="text-[11px] font-bold text-slate-700 truncate">Credentials: {doc.qualification}</p>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-relaxed font-semibold mb-2">{doc.bio}</p>
                    </div>

                    {/* Availability details block */}
                    <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl text-[11px] space-y-1.5">
                      <div className="flex justify-between items-center text-slate-600">
                        <span className="font-bold flex items-center gap-1">
                          <Clock size={11} className="text-slate-400" />
                          <span>Consultation Hours:</span>
                        </span>
                        <span className="font-extrabold text-slate-800">{doc.timings}</span>
                      </div>
                      <div className="flex justify-between items-center text-slate-600">
                        <span className="font-bold flex items-center gap-1">
                          <Calendar size={11} className="text-slate-400" />
                          <span>Scheduled Days:</span>
                        </span>
                        <span className="font-semibold text-slate-705 truncate max-w-[150px] text-right">{doc.days.join(", ")}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions line */}
                  <div className="pt-3 border-t border-slate-100 flex justify-between items-center bg-white">
                    <span className="text-[11px] text-slate-500 font-bold">Experience: <strong className="text-slate-800">{doc.experience}</strong></span>
                    {doc.availableToday ? (
                      <Link
                        to="/receptionist"
                        className="text-[11px] text-teal-600 font-extrabold hover:text-teal-700 hover:underline flex items-center gap-0.5 cursor-pointer bg-teal-50 px-2.5 py-1 rounded-md border border-teal-200/50"
                      >
                        <span>Join Queue</span>
                        <ChevronRight size={12} />
                      </Link>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-bold">Resumes: {doc.days[0]}</span>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200/60 max-w-2xl mx-auto">
              <Stethoscope className="mx-auto text-slate-300 mb-3" size={36} />
              <p className="text-sm font-bold text-slate-700">No matching medical practitioners found</p>
              <p className="text-xs text-slate-400 mt-1">Please try clearing your filters, resetting queries, or checking back during OPD hours.</p>
              <button
                onClick={() => { setSelectedSpecialty("All"); setSearchQuery(""); setShowAvailableOnly(false); }}
                className="mt-4 text-xs font-bold bg-slate-900 text-white rounded-xl py-2 px-4 hover:bg-slate-800 transition-colors"
              >
                Reset Search Filters
              </button>
            </div>
          )}
        </section>

        {/* Quick Help Guide */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/60 shadow-2xs mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-1">
            <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">1. Walk-In Registration</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
              Generate a digital ticket token at our Reception Desk using your full name, age, gender, and preferred specialist category.
            </p>
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">2. Digital Live Lounging</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
              Watch announcements on our digital waiting room boards. Follow remaining counts, average timer calculations, and custom triage notifications.
            </p>
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">3. Direct Consultations</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
              When the systems alert your visual token number, proceed to the diagnosed doctor's clinic cabin for active physical/family health consultancy.
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}
