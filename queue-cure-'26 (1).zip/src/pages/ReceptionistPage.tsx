/**
 * @file ReceptionistPage.tsx
 * @description Receptionist Dashboard screen.
 * Beautiful bento grid structure combining custom styling, light theme, high-contrast layouts.
 */

import React, { useState, useEffect } from "react";
import { socket } from "../socket.js";
import logoImg from "./hospital.png";
import { PatientForm } from "../components/PatientForm.tsx";
import { QueueList, Patient } from "../components/QueueList.tsx";
import { Play, Users, Clock, Save, CalendarRange, Activity, AlertCircle } from "lucide-react";

export const ReceptionistPage: React.FC = () => {
  // States of the queue synchronized from backend
  const [patients, setPatients] = useState<Patient[]>([]);
  const [currentToken, setCurrentToken] = useState<string | null>(null);
  const [totalWaiting, setTotalWaiting] = useState<number>(0);
  const [avgConsultTime, setAvgConsultTime] = useState<number>(5);

  // Receptionist input for setting Average Consult Time
  const [inputAvgTime, setInputAvgTime] = useState<string>("5");
  const [settingsStatus, setSettingsStatus] = useState<string>("");

  // Loading indicator for API calls
  const [isCallingNext, setIsCallingNext] = useState(false);

  // Core setup: Fetch initial state and register socket listeners for instant UI updates
  useEffect(() => {
    // 1. Fetch initial queue history on component mount (Initial Sync)
    const fetchQueueState = async () => {
      try {
        const res = await fetch("/api/queue");
        if (!res.ok) throw new Error("Failed to load queue state");
        const data = await res.json();
        setPatients(data.queue || []);
        setCurrentToken(data.currentToken);
        setTotalWaiting(data.totalWaiting);
        setAvgConsultTime(data.avgConsultTime || 5);
        setInputAvgTime(String(data.avgConsultTime || 5));
      } catch (err) {
        console.error("Error doing initial sync:", err);
      }
    };

    fetchQueueState();

    // 2. Synchronize in real-time when notifications arrive from WebSocket
    socket.on("queue-updated", (payload: { queue: Patient[]; currentToken: string | null; totalWaiting: number; avgConsultTime: number }) => {
      console.log("Real-time queue-updated event received:", payload);
      setPatients(payload.queue);
      setCurrentToken(payload.currentToken);
      setTotalWaiting(payload.totalWaiting);
      setAvgConsultTime(payload.avgConsultTime);
      setInputAvgTime(String(payload.avgConsultTime));
    });

    // Clean up connections on unmount
    return () => {
      socket.off("queue-updated");
    };
  }, []);

  // Action: Add patient to queue (POST to REST controller)
  const handleAddPatient = async (name: string, age?: number, gender?: string, doctorId?: string) => {
    const response = await fetch("/api/patients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, age, gender, doctorId }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || "Failed to add patient to queue");
    }
  };

  // Action: Call next patient (POST to REST controller)
  const handleCallNext = async () => {
    if (isCallingNext) return;
    try {
      setIsCallingNext(true);
      const res = await fetch("/api/call-next", { method: "POST" });
      if (!res.ok) throw new Error("Failed to advance queue");
      
      const data = await res.json();
      // On success, backend broadcasts the changes, handled by 'queue-updated' socket event
    } catch (err: any) {
      alert(err.message || "Could not summon next patient.");
    } finally {
      setIsCallingNext(false);
    }
  };

  // Action: Modify global consultation settings (POST to REST controller)
  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsStatus("");
    const numericTime = Number(inputAvgTime);

    if (isNaN(numericTime) || numericTime <= 0) {
      setSettingsStatus("Must be a number greater than 0");
      return;
    }

    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avgConsultTime: numericTime }),
      });

      if (!res.ok) throw new Error("Failed to save settings");
      setSettingsStatus("Saved successfully!");
      setTimeout(() => setSettingsStatus(""), 2500);
    } catch (err) {
      setSettingsStatus("Error saving settings.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans p-4 sm:p-6 md:p-8 flex flex-col gap-6">
      {/* Clinic Header (Bento Styled) */}
      <header className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden shadow-xs border border-slate-200 shrink-0">
            <img
              src={logoImg}
              alt="Queue Cure Clinic Logo"
              className="object-cover w-full h-full"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Queue Cure Clinic</h1>
            <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Reception Desk Console</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-teal-50 text-teal-850 border border-teal-200/50 px-3 py-1.5 rounded-full text-xs font-bold font-mono">
          <span className="h-2 w-2 rounded-full bg-teal-500 animate-pulse" />
          SYSTEM: ONLINE & LIVE
        </div>
      </header>

      {/* Main Bento Grid Container */}
      <main className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Column Controls - span 4 / 12 */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Bento Box 1: Patient Check-In */}
          <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col gap-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <span className="p-1 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
                <svg
                  viewBox="0 0 100 100"
                  className="w-6 h-6 shrink-0"
                  aria-hidden="true"
                >
                  {/* Underneath/Background Card */}
                  <rect
                    x="16"
                    y="16"
                    width="74"
                    height="74"
                    rx="10"
                    fill="#e0e7ff"
                    stroke="#1e293b"
                    strokeWidth="4.5"
                    strokeLinejoin="round"
                  />
                  {/* Main / Front Card */}
                  <rect
                    x="10"
                    y="10"
                    width="74"
                    height="74"
                    rx="10"
                    fill="#f8fafc"
                    stroke="#1e293b"
                    strokeWidth="4.5"
                    strokeLinejoin="round"
                  />
                  {/* Header Teal Bar on Front Card with rounded top corners */}
                  <path
                    d="M 10,24 H 84 V 18 A 8,8 0 0,0 76,10 H 18 A 8,8 0 0,0 10,18 Z"
                    fill="#2dd4bf"
                    stroke="#1e293b"
                    strokeWidth="4.5"
                    strokeLinejoin="round"
                  />
                  {/* Header Mini Dots */}
                  <circle cx="64" cy="17" r="2" fill="#1e293b" />
                  <circle cx="70" cy="17" r="2" fill="#1e293b" />
                  <circle cx="76" cy="17" r="2" fill="#1e293b" />

                  {/* Left Avatar box */}
                  <rect
                    x="17"
                    y="31"
                    width="28"
                    height="28"
                    rx="5"
                    fill="#ccfbf1"
                    stroke="#1e293b"
                    strokeWidth="3.5"
                    strokeLinejoin="round"
                  />
                  {/* Avatar Head */}
                  <circle
                    cx="31"
                    cy="41"
                    r="4.5"
                    fill="#fbcfe8"
                    stroke="#1e293b"
                    strokeWidth="2.5"
                  />
                  {/* Avatar Shoulders */}
                  <path
                    d="M 22,54 C 22,48 26,48 31,48 C 36,48 40,48 40,54 Z"
                    fill="#93c5fd"
                    stroke="#1e293b"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                  />

                  {/* Right Red Plus Sign */}
                  <path
                    d="M 59,33 H 65 V 37 H 69 V 43 H 65 V 47 H 59 V 43 H 55 V 37 H 59 Z"
                    fill="#f43f5e"
                    stroke="#1e293b"
                    strokeWidth="3"
                    strokeLinejoin="round"
                  />

                  {/* Text lines on right under Plus */}
                  <line
                    x1="52"
                    y1="51"
                    x2="74"
                    y2="51"
                    stroke="#1e293b"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  <line
                    x1="52"
                    y1="57"
                    x2="74"
                    y2="57"
                    stroke="#1e293b"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />

                  {/* Bottom Text lines on Front Card */}
                  <line
                    x1="18"
                    y1="68"
                    x2="76"
                    y2="68"
                    stroke="#1e293b"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  <line
                    x1="18"
                    y1="75"
                    x2="76"
                    y2="75"
                    stroke="#1e293b"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
              <h2 className="font-extrabold text-sm text-slate-700 uppercase tracking-widest">
                Check-In Portal
              </h2>
            </div>
            <PatientForm onAddPatient={handleAddPatient} id="receptionist-reg" />
          </section>

          {/* Bento Box 2: Speed Settings */}
          <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col gap-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <span className="p-0.5 rounded-lg flex items-center justify-center shrink-0">
                <svg
                  viewBox="0 0 100 100"
                  className="w-7 h-7 shrink-0"
                  aria-hidden="true"
                >
                  {/* Outer Bezel Ring */}
                  <circle cx="50" cy="50" r="44" fill="#0d416b" stroke="#082944" strokeWidth="3" />
                  {/* Bezel Inner highlight / Inner dark circle edge */}
                  <circle cx="50" cy="50" r="39" fill="#0c3558" />
                  {/* Main Face white background */}
                  <circle cx="50" cy="50" r="36" fill="#ffffff" />
                  {/* Left side face crescent shadow */}
                  <path d="M 50,14 A 36,36 0 0,0 50,86 A 35,35 0 0,1 28,50 A 35,35 0 0,1 50,14 Z" fill="#dae3eb" opacity="0.8" />
                  
                  {/* Hour Ticks */}
                  {/* 12, 3, 6, 9 Ticks */}
                  <line x1="50" y1="14" x2="50" y2="20" stroke="#0d3559" strokeWidth="2.5" strokeLinecap="round" transform="rotate(0, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="20" stroke="#0d3559" strokeWidth="2.5" strokeLinecap="round" transform="rotate(90, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="20" stroke="#0d3559" strokeWidth="2.5" strokeLinecap="round" transform="rotate(180, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="20" stroke="#0d3559" strokeWidth="2.5" strokeLinecap="round" transform="rotate(270, 50, 50)" />
                  
                  {/* Other intermediate Hours ticks */}
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(30, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(60, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(120, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(150, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(210, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(240, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(300, 50, 50)" />
                  <line x1="50" y1="14" x2="50" y2="18" stroke="#0d3559" strokeWidth="1.5" strokeLinecap="round" transform="rotate(330, 50, 50)" />
                  
                  {/* Hands */}
                  {/* Shorter thicker Hour Hand */}
                  <path d="M 48.5,50 L 49.2,27 A 1.2,1.2 0 0,1 50.8,27 L 51.5,50 Z" fill="#0d416b" transform="rotate(345, 50, 50)" />
                  {/* Longer thinner Minute Hand */}
                  <path d="M 49,50 L 49.4,20 A 0.8,0.8 0 0,1 50.6,20 L 51,50 Z" fill="#0d416b" transform="rotate(70, 50, 50)" />
                  
                  {/* Gold/Yellow Center Pin */}
                  <circle cx="50" cy="50" r="4.5" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                </svg>
              </span>
              <h2 className="font-extrabold text-sm text-slate-700 uppercase tracking-widest">
                clinical delay
              </h2>
            </div>
            <form onSubmit={handleUpdateSettings} className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1 tracking-wider">
                  Avg Consultation Time (in mins)
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none font-mono"
                    value={inputAvgTime}
                    onChange={(e) => setInputAvgTime(e.target.value)}
                  />
                  <button
                    type="submit"
                    className="cursor-pointer bg-slate-900 hover:bg-slate-850 active:scale-95 text-white py-3 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <Save size={15} />
                    <span>Save</span>
                  </button>
                </div>
                {settingsStatus && (
                  <span className={`text-xs font-bold mt-1 ml-1 ${
                    settingsStatus.includes("error") || settingsStatus.includes("greater") ? "text-rose-600" : "text-emerald-700"
                  }`}>
                    {settingsStatus}
                  </span>
                )}
              </div>
            </form>
          </section>

          {/* Bento Box 3: Call Control (Action Required from Bento Spec) */}
          <section className="bg-teal-600 p-6 rounded-3xl text-white shadow-md shadow-teal-605/10 flex flex-col justify-between min-h-[160px]">
            <div className="space-y-1">
              <p className="text-xs opacity-90 uppercase font-black tracking-widest">Clinical Action</p>
              <h3 className="text-xl font-bold tracking-tight">Call Next Patient</h3>
              <p className="text-xs opacity-80 leading-relaxed">
                Advance the list and mark the next patient as 'In Consultation'. This immediately alerts the waiting room lounge display.
              </p>
            </div>
            <button
              id="call-next-btn"
              onClick={handleCallNext}
              disabled={isCallingNext || totalWaiting === 0}
              className="mt-4 w-full cursor-pointer flex items-center justify-center gap-2 bg-slate-900 text-white hover:bg-slate-800 disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed font-extrabold py-3.5 px-6 rounded-xl shadow-xs tracking-wide transition-all text-sm active:scale-[0.98]"
            >
              <Play size={16} className="fill-current text-white" />
              <span>{isCallingNext ? "Summoning..." : `Summon Next (Waiting: ${totalWaiting})`}</span>
            </button>
          </section>
        </div>

        {/* Right Column Queue Status - span 8 / 12 */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Prominent Visual Counters Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Serving State Box (Dark High-Contrast Bento) */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 relative overflow-hidden flex flex-col justify-between min-h-[150px]">
              {/* Background gradient flare */}
              <div className="absolute top-0 right-0 h-32 w-32 bg-emerald-500/10 rounded-full blur-2xl" />
              
              <div className="flex items-center justify-between relative z-10">
                <span className="text-xs tracking-wider font-extrabold uppercase text-slate-400">
                  Active Consultation Room
                </span>
                <span className="p-1 rounded-md bg-white/10 text-emerald-400 animate-pulse">
                  <Activity size={14} />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-3 relative z-10">
                {currentToken ? (
                  <>
                    <span className="text-5xl font-black font-mono tracking-tight text-white">{currentToken}</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/15 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider border border-emerald-500/20">
                      In consultation
                    </span>
                  </>
                ) : (
                  <span className="text-3xl font-extrabold tracking-tight text-slate-300">Vacant Desk</span>
                )}
              </div>
              <p className="text-xs text-slate-400 font-medium mt-2 relative z-10 leading-relaxed">
                {currentToken
                  ? "Ongoing consult. Click 'Summon Next' once completed."
                  : "Desk is ready to receive patients. Trigger Call Next."}
              </p>
            </div>

            {/* Patients Waiting Box */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col justify-between min-h-[150px]">
              <div className="flex items-center justify-between">
                <span className="text-xs tracking-wider font-extrabold uppercase text-slate-500">
                  Patients Awaiting
                </span>
                <span className="p-2 rounded-xl bg-teal-50 text-teal-600">
                  <Users size={16} />
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-5xl font-black text-slate-850">{totalWaiting}</span>
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wide">Patients</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mt-2">
                <Clock size={12} className="text-teal-600 shrink-0" />
                <span>Estimated Queue Time: <strong className="text-teal-600 font-bold">{totalWaiting * avgConsultTime} mins</strong></span>
              </div>
            </div>
          </div>

          {/* Section: All patients grid list */}
          <div className="flex-1 flex flex-col justify-stretch">
            <QueueList patients={patients} id="receptionist-list" />
          </div>
        </div>
      </main>
    </div>
  );
};
