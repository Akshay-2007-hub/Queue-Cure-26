/**
 * @file WaitingRoomPage.tsx
 * @description Patient Waiting Room monitor and ticker page styled as a modern Bento Grid.
 * Incorporates beautiful light backgrounds, massive dark consultation display, and structured bento list blocks.
 */

import React, { useState, useEffect } from "react";
import { socket } from "../socket.js";
import logoImg from "./hospital.png";
import { WaitEstimate } from "../components/WaitEstimate.tsx";
import { Patient } from "../components/QueueList.tsx";
import { MonitorPlay, Users, Clock, CalendarClock, Bell, Stethoscope } from "lucide-react";
import { getDoctorById } from "../doctorsData";

export const WaitingRoomPage: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [currentToken, setCurrentToken] = useState<string | null>(null);
  const [totalWaiting, setTotalWaiting] = useState<number>(0);
  const [avgConsultTime, setAvgConsultTime] = useState<number>(5);

  // Audio state tracker for chime notifications
  const [calledHistory, setCalledHistory] = useState<string[]>([]);

  // Setup Socket listener to refresh clinical status in real time
  useEffect(() => {
    // 1. Initial State Sync via Fetch
    const fetchQueueState = async () => {
      try {
        const res = await fetch("/api/queue");
        if (!res.ok) throw new Error("Could not load initial queue");
        const data = await res.json();
        setPatients(data.queue || []);
        setCurrentToken(data.currentToken);
        setTotalWaiting(data.totalWaiting);
        setAvgConsultTime(data.avgConsultTime || 5);
      } catch (err) {
        console.error("Initial load failure:", err);
      }
    };

    fetchQueueState();

    // 2. Register live WebSocket updates
    socket.on("queue-updated", (payload: { queue: Patient[]; currentToken: string | null; totalWaiting: number; avgConsultTime: number }) => {
      console.log("WaitingRoom received queue update:", payload);
      setPatients(payload.queue);
      setCurrentToken(payload.currentToken);
      setTotalWaiting(payload.totalWaiting);
      setAvgConsultTime(payload.avgConsultTime);
    });

    // 3. Receive token voice-calling chime trigger
    socket.on("token-called", (payload: { token: string; name: string }) => {
      console.log("Sound announcement or alert triggered for:", payload);
      setCalledHistory((prev) => [payload.token, ...prev.slice(0, 4)]);
      
      // Simple non-intrusive sound synthesis if supported
      try {
         const sndCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
         const osc = sndCtx.createOscillator();
         const gain = sndCtx.createGain();
         osc.connect(gain);
         gain.connect(sndCtx.destination);
         osc.frequency.setValueAtTime(523.25, sndCtx.currentTime); // C5 note
         gain.gain.setValueAtTime(0.3, sndCtx.currentTime);
         gain.gain.exponentialRampToValueAtTime(0.01, sndCtx.currentTime + 0.3);
         osc.start(sndCtx.currentTime);
         osc.stop(sndCtx.currentTime + 0.3);
      } catch {
        // Safe check for browser auto-play blockers
      }
    });

    return () => {
      socket.off("queue-updated");
      socket.off("token-called");
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans p-4 sm:p-6 md:p-8 flex flex-col gap-6">
      {/* Clinic Header (Bento Styled) */}
      <header className="bg-white border border-slate-200/80 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden shadow-xs border border-slate-200 shrink-0">
            <img
              src={logoImg}
              alt="Queue Cure Clinic Logo"
              className="object-cover w-full h-full"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 font-sans">Queue Cure Clinic</h1>
            <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Patient Waiting Lounge Screen</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-teal-50 text-teal-800 border border-teal-200/50 px-3.5 py-1.5 rounded-full text-xs font-bold font-mono">
          <span className="h-2 w-2 rounded-full bg-teal-500 animate-pulse" />
          TV LOBBY MONITOR ACTIVE
        </div>
      </header>
      {/* Main interactive and display panel */}
      <main className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Section: Gigantic Wall Mount Display (Stunning Dark Bento Box) */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-8 flex-1 flex flex-col items-center justify-center text-center relative overflow-hidden shadow-2xl min-h-[420px]">
            {/* Background elements */}
            <div className="absolute top-0 right-0 h-64 w-64 bg-teal-500/5 rounded-full blur-3xl" />
            
            <div className="space-y-4 relative z-10 flex flex-col items-center">
              <span className="inline-flex items-center gap-1.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-full">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
                Active Consultation Room
              </span>
              <h2 className="text-slate-400 text-sm font-bold tracking-widest uppercase">
                Now Serving Patient
              </h2>
            </div>

            <div className="my-8 relative z-10">
              {currentToken ? (
                <div className="space-y-4">
                  {/* Huge Token display */}
                  <div className="text-[7.5rem] sm:text-[9.5rem] font-black leading-none text-white font-mono tracking-tighter">
                    {currentToken}
                  </div>
                  {/* Active patient identity helper */}
                  {(() => {
                    const activePatient = patients.find(p => p.token === currentToken);
                    if (!activePatient) return null;
                    const activeDoctor = getDoctorById(activePatient.doctorId);
                    
                    return (
                      <div className="flex flex-col items-center gap-2">
                        <p className="text-lg text-slate-300 font-bold capitalize mt-2 flex justify-center items-baseline gap-1.5 font-sans">
                          <span>{activePatient.name}</span>
                          {(activePatient.age !== undefined && activePatient.age !== null || activePatient.gender) && (
                            <span className="text-sm font-medium text-slate-450">
                              ({[activePatient.age !== undefined && activePatient.age !== null ? `${activePatient.age} yrs` : "", activePatient.gender].filter(Boolean).join(" • ")})
                            </span>
                          )}
                        </p>
                        {activeDoctor && (
                          <div className="mt-2 bg-teal-500/10 border border-teal-500/20 text-teal-300 px-4 py-2.5 rounded-2xl text-xs inline-flex items-center gap-2.5 max-w-sm mx-auto shadow-xs">
                            <span className="p-1.5 rounded-lg bg-teal-500/15 text-teal-400">
                              <Stethoscope size={14} className="shrink-0" />
                            </span>
                            <div className="text-left">
                              <p className="font-extrabold uppercase tracking-widest text-[8px] text-teal-400/80">Consulting Room Physician</p>
                              <p className="font-bold text-white text-xs">{activeDoctor.name}</p>
                              <p className="text-[10px] text-teal-300 font-medium">{activeDoctor.specialization} &bull; {activeDoctor.qualification}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              ) : (
                <div className="space-y-3 py-4">
                  <MonitorPlay className="mx-auto text-slate-700 animate-pulse stroke-[1.2]" size={72} />
                  <p className="text-2xl font-black text-slate-400 tracking-wide font-sans">Queue Room Idle</p>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    The doctor is currently preparing. Next patient will reflect here instantly.
                  </p>
                </div>
              )}
            </div>

            <div className="w-full border-t border-slate-800 pt-6 mt-4 flex items-center justify-around text-sans text-xs">
              <div className="text-center">
                <p className="text-slate-500 uppercase tracking-widest font-black text-[10px]">Avg Speed</p>
                <div className="flex items-center gap-1 justify-center mt-1 text-slate-300 font-bold font-sans">
                  <Clock size={12} className="text-slate-400" />
                  <span>~{avgConsultTime} mins / pat</span>
                </div>
              </div>
              <div className="h-6 w-px bg-slate-800" />
              <div className="text-center">
                <p className="text-slate-500 uppercase tracking-widest font-black text-[10px]">Awaiting</p>
                <div className="flex items-center gap-1 justify-center mt-1 text-slate-300 font-bold font-sans">
                  <Users size={12} className="text-slate-400" />
                  <span>{totalWaiting} patients</span>
                </div>
              </div>
            </div>
          </div>

          {/* Sound Notification Banner of recently called */}
          {calledHistory.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center justify-between text-xs shadow-sm">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-md bg-amber-50 text-amber-600 animate-bounce">
                  <Bell size={14} />
                </span>
                <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">Recently Called:</span>
              </div>
              <div className="flex gap-2">
                {calledHistory.map((tok, idx) => (
                  <span
                    key={`${tok}-${idx}`}
                    className={`font-mono text-xs font-black px-3 py-1 rounded-lg border ${
                      idx === 0 
                        ? "bg-emerald-50 text-emerald-700 border-emerald-250 animate-pulse" 
                        : "bg-slate-50 text-slate-500 border-slate-200"
                    }`}
                  >
                    {tok}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Section: Mobile Patient Tracker lookup & List */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Tracker Card widget */}
          <WaitEstimate patients={patients} avgConsultTime={avgConsultTime} id="patient-room-estimate" />

          {/* Bento Box: Waiting line-up list */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col gap-4 max-h-[380px] overflow-y-auto">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                  <svg
                    viewBox="0 0 100 100"
                    className="w-4 h-4 text-amber-600 fill-current shrink-0"
                    aria-hidden="true"
                  >
                    {/* Doorway */}
                    <rect x="83" y="20" width="12" height="60" rx="4" fill="none" stroke="currentColor" strokeWidth="5" />
                    
                    {/* Ground */}
                    <line x1="5" y1="80" x2="95" y2="80" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
                    
                    {/* Person 1 */}
                    <circle cx="65" cy="32" r="7" />
                    <path d="M57,45 A5,5 0 0,1 62,40 H68 A5,5 0 0,1 73,45 V76 H57 Z" />
                    
                    {/* Person 2 */}
                    <circle cx="40" cy="32" r="7" opacity="0.75" />
                    <path d="M32,45 A5,5 0 0,1 37,40 H43 A5,5 0 0,1 48,45 V76 H32 Z" opacity="0.75" />
                    
                    {/* Person 3 */}
                    <circle cx="15" cy="32" r="7" opacity="0.5" />
                    <path d="M7,45 A5,5 0 0,1 12,40 H18 A5,5 0 0,1 23,45 V76 H7 Z" opacity="0.5" />
                    
                    {/* Spacing Arrows */}
                    <path d="M22,76 H33 M31,73 L34,76 L31,79" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                    <path d="M47,76 H58 M56,73 L59,76 L56,79" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                  </svg>
                </span>
                <h3 className="font-extrabold text-sm uppercase tracking-widest text-slate-700 font-sans">
                  Upcoming Lineup
                </h3>
              </div>
              <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                {patients.filter(p => p.status === 'waiting').length} waiting
              </span>
            </div>
            
            {patients.filter(p => p.status === 'waiting').length === 0 ? (
              <p className="text-xs text-slate-400 py-8 text-center font-semibold">No patients are waiting in line.</p>
            ) : (
              <div className="space-y-2 pt-1">
                {patients
                  .filter(p => p.status === 'waiting')
                  .map((pat, idx) => {
                    const inlineDoc = getDoctorById(pat.doctorId);
                    return (
                      <div key={pat.token} className="flex items-center justify-between bg-slate-50 border border-slate-150 rounded-xl p-3 shadow-xs gap-3">
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[10px] font-mono font-bold text-slate-400">#{idx + 1}</span>
                          <span className="font-mono text-sm font-black text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-150">
                            {pat.token}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0 pr-2">
                          <span className="text-xs font-bold text-slate-700 capitalize flex items-baseline gap-1 select-none" title={pat.name}>
                            <span className="truncate">{pat.name}</span>
                            {(pat.age !== undefined && pat.age !== null || pat.gender) && (
                              <span className="text-[10px] font-medium text-slate-500 shrink-0">
                                ({[pat.age !== undefined && pat.age !== null ? `${pat.age} yrs` : "", pat.gender].filter(Boolean).join(" • ")})
                              </span>
                            )}
                          </span>
                          {inlineDoc && (
                            <div className="text-[9px] text-teal-850 font-bold flex items-center gap-1 mt-0.5 truncate select-none">
                              <span className="bg-teal-50/70 text-teal-800 border border-teal-250/20 px-1.5 py-0.2 rounded-sm text-[9px] font-semibold truncate max-w-full">
                                {inlineDoc.specialization} &bull; {inlineDoc.name}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="text-right text-[10px] font-mono font-bold text-slate-500 shrink-0">
                          {idx * avgConsultTime}m wait
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>

          <div className="text-center py-2 text-[10px] text-slate-400 font-semibold tracking-wider uppercase select-none font-sans">
            QUEUE CURE CLINIC • DIGITAL SERVICES DEPLOYED
          </div>
        </div>
      </main>
    </div>
  );
};
