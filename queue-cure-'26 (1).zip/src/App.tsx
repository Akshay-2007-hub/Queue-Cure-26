/**
 * @file App.tsx
 * @description Root client application coordinator. Configures Routing paths
 * and adds a floating viewport switcher so judges can toggle console roles.
 */

import { useState } from "react";
import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import logoImg from "./pages/hospital.png";
import { HomePage } from "./pages/HomePage.tsx";
import { DoctorsPage } from "./pages/DoctorsPage.tsx";
import { ReceptionistPage } from "./pages/ReceptionistPage.tsx";
import { WaitingRoomPage } from "./pages/WaitingRoomPage.tsx";
import { 
  RefreshCw, 
  Users, 
  ShieldAlert, 
  Home, 
  Stethoscope, 
  Menu, 
  X, 
  LayoutGrid, 
  ChevronDown 
} from "lucide-react";

// Top-Left Floating Multi-Page Navigation Menu
function TopLeftMoreMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const currentPath = location.pathname;

  const pages = [
    {
      path: "/",
      label: "Clinic Home",
      description: "Primary diagnostics website",
      icon: <Home size={16} className="text-teal-500" />,
      colorClass: "hover:bg-teal-50/50"
    },
    {
      path: "/doctors",
      label: "Doctor Directory",
      description: "Specialist schedules & details",
      icon: <Stethoscope size={16} className="text-emerald-500" />,
      colorClass: "hover:bg-emerald-50/50"
    },
    {
      path: "/waiting",
      label: "Waiting Room Lobby",
      description: "Live token tracker lobby",
      icon: <Users size={16} className="text-amber-500" />,
      colorClass: "hover:bg-amber-50/50"
    },
    {
      path: "/receptionist",
      label: "Receptionist Console",
      description: "Staff patient registration",
      icon: <ShieldAlert size={16} className="text-rose-500" />,
      colorClass: "hover:bg-rose-50/50"
    }
  ];

  return (
    <>
      <div className="fixed top-2.5 left-2.5 md:top-3 md:left-3 z-[99999] font-sans">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-extrabold select-none transition-all shadow-md active:scale-95 border ${
            isOpen 
              ? "bg-slate-900 text-white border-slate-800" 
              : "bg-white/95 text-slate-800 border-slate-200/80 hover:bg-white hover:shadow-lg hover:shadow-slate-300/30"
          }`}
          title="More Options"
        >
          {isOpen ? <X size={14} /> : <Menu size={14} />}
          <span>More Options</span>
          <ChevronDown size={12} className={`opacity-60 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
        </button>

        {isOpen && (
          <div className="absolute top-11 left-0 mt-2 w-72 bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/80 shadow-2xl overflow-hidden py-2.5 z-[99999] animate-in fade-in slide-in-from-top-3 duration-200">
            <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-slate-550 tracking-wider flex items-center gap-2 font-sans">
                <img
                  src={logoImg}
                  alt="Clinic Logo"
                  className="w-4 h-4 rounded-xs object-cover"
                  referrerPolicy="no-referrer"
                />
                Queue Cure Clinic
              </span>
              <span className="text-[9px] bg-slate-100 text-slate-550 px-1.5 py-0.5 rounded-md font-bold font-mono">
                Active Zone
              </span>
            </div>

            <div className="mt-2 px-2 space-y-1">
              {pages.map((p) => {
                const isActive = currentPath === p.path;
                return (
                  <Link
                    key={p.path}
                    to={p.path}
                    onClick={() => setIsOpen(false)}
                    className={`flex items-start gap-3 p-2.5 rounded-xl transition-all cursor-pointer ${p.colorClass} ${
                      isActive 
                        ? "bg-slate-100/80 border-l-4 border-teal-600 pl-2" 
                        : "border-l-4 border-transparent"
                    }`}
                  >
                    <div className="p-2 bg-slate-50 rounded-lg shrink-0 mt-0.5">
                      {p.icon}
                    </div>
                    <div className="min-w-0 font-sans">
                      <p className={`text-xs font-extrabold ${isActive ? "text-teal-950 font-black" : "text-slate-800"}`}>
                        {p.label}
                      </p>
                      <p className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
                        {p.description}
                      </p>
                    </div>
                  </Link>
                );
              })}
            </div>

            <div className="mt-2.5 pt-2.5 border-t border-slate-100 px-4 text-center">
              <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                &bull; Queue Cure Clinic &bull; Chennai
              </p>
            </div>
          </div>
        )}
      </div>

      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)} 
          className="fixed inset-0 z-[99998] bg-slate-900/10 backdrop-blur-xs transition-opacity"
        />
      )}
    </>
  );
}

// Floating navigation controller for quick workspace swapping in AI Studio
function ModeToggle() {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <div className="fixed bottom-4 right-4 z-50 font-sans shadow-xl rounded-full flex items-center bg-white/95 backdrop-blur-md border border-slate-250 p-1.5 gap-1 shadow-slate-300">
      <Link
        to="/"
        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold select-none transition-all ${
          currentPath === "/"
            ? "bg-slate-900 text-white"
            : "text-slate-600 hover:bg-slate-100"
        }`}
      >
        <Home size={12} />
        <span>Home</span>
      </Link>
      <Link
        to="/doctors"
        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold select-none transition-all ${
          currentPath === "/doctors"
            ? "bg-slate-900 text-white"
            : "text-slate-600 hover:bg-slate-100"
        }`}
      >
        <Stethoscope size={12} />
        <span>Doctor Info</span>
      </Link>
      <Link
        to="/waiting"
        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold select-none transition-all ${
          currentPath === "/waiting"
            ? "bg-slate-900 text-white"
            : "text-slate-600 hover:bg-slate-100"
        }`}
      >
        <Users size={12} />
        <span>Waiting Room</span>
      </Link>
      <Link
        to="/receptionist"
        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold select-none transition-all ${
          currentPath === "/receptionist"
            ? "bg-slate-900 text-white"
            : "text-slate-600 hover:bg-slate-100"
        }`}
      >
        <ShieldAlert size={12} />
        <span>Receptionist Admin</span>
      </Link>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      {/* Universal Top-Left Navigation Menu */}
      <TopLeftMoreMenu />

      <Routes>
        {/* Receptionist Route */}
        <Route path="/receptionist" element={<ReceptionistPage />} />
        
        {/* Patient Lounge Routes */}
        <Route path="/waiting" element={<WaitingRoomPage />} />
        
        {/* Doctor Info Route */}
        <Route path="/doctors" element={<DoctorsPage />} />
        
        {/* Clinic Home Route */}
        <Route path="/" element={<HomePage />} />
      </Routes>

      {/* View Switcher for Sandbox Navigation */}
      <ModeToggle />
    </BrowserRouter>
  );
}
