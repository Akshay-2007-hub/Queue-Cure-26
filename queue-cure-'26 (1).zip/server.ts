/**
 * @file server.ts
 * @description Main unified entry point. Sets up Express, HTTP server, matches socket.io
 * and configures Vite middleware in development or hosts build artifacts in production.
 * Runs on Port 3000.
 */

import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import path from "path";
import { createServer as createViteServer } from "vite";

// Import custom backend elements
import patientsRouter from "./backend/routes/patients";
import queueRouter from "./backend/routes/queue";
import settingsRouter from "./backend/routes/settings";
import { getQueueSummary } from "./backend/state/queueState";

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  
  // 1. Configure the Socket.io Server
  // Supports cross-origin routing for robust local debugging or production hosting.
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // 2. Set storage alias "io" inside app context so endpoints can publish updates easily
  app.set("io", io);

  // 3. Middlewares for payload parsing
  app.use(express.json());

  // 4. Register REST Endpoints
  app.use("/api/patients", patientsRouter);
  app.use("/api", queueRouter);
  app.use("/api/settings", settingsRouter);

  // 5. Connect Socket connections for real-time syncing
  io.on("connection", (socket) => {
    console.log(`Patient or Receptionist connected: ${socket.id}`);
    
    // Instantly send current queue status to newly connected screen (Initial Sync)
    socket.emit("queue-updated", getQueueSummary());

    socket.on("disconnect", () => {
      console.log(`Socket client disconnected: ${socket.id}`);
    });
  });

  // 6. Integrate Vite: Serve dev middleware or compiled production production bundle
  const PORT = 3000;
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // For Production: serve ready built HTML, CSS, Javascript
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Bind to host 0.0.0.0 to satisfy Cloud Run routing
  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Clinic Management active on: http://0.0.0.0:${PORT}`);
  });
}

// Kickstart server
startServer().catch((err) => {
  console.error("Failed to bootstrap fullstack server:", err);
});
