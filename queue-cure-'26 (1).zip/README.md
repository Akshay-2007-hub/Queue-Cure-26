# Queue Cure '26 — Live Clinic Queue Manager

An award-ready, real-time clinical queue management web application designed for the Wooble Hackathon '26.

## 1. Problem Statement
Every day, India's 1.5 million neighborhood micro-clinics run on noisy, paper-bound tokens or vocal roll calls, forcing unwell patients to stand in congested lobby blocks for hours without any visibility on arrival timing. **Queue Cure '26** replaces this bottleneck with a live, real-time digital monitor system, allowing patients to check checkout estimates on their phones while administrators orchestrate the cabin workflow from an digital desk dashboard.

---

## 2. Tech Stack
- **Frontend Core:** React.js (Vite, TypeScript, Tailwind CSS)
- **Styling:** Tailwind CSS utility style guidelines
- **Real-Time Sync Engine:** Socket.io (server) + Socket.io-Client (client)
- **Backend Infrastructure:** Express on Node.js with built-in HTTP server handlers
- **Routing Engine:** React Router (configured for multi-monitor routing)
- **Visual Utilities:** Lucide React icons

---

## 3. How to Run Locally
The project contains an integrated full-stack layout, making local setup incredibly simple and avoiding custom CORS configurations!

### Quickstart (Fully Unified Server)
1. **Clone & Setup:**
   ```bash
   npm install
   ```
2. **Execute Development Mode:**
   ```bash
   npm run dev
   ```
   *This starts the Express server which hosts the active Socket.io listeners and mounts Vite development middleware on [http://localhost:3000](http://localhost:3000) automatically!*

3. **Production Compilation:**
   ```bash
   npm run build
   ```
   *This builds compiled static React assets and bundles the Express server using esbuild into `dist/server.cjs`.*

4. **Start Production Service:**
   ```bash
   npm run start
   ```

---

## 4. Socket Event Diagram

```mermaid
sequenceDiagram
    autonumber
    actor Rec as Client (Receptionist)
    participant Srv as Live Server (Express+Socket.io)
    actor Pat as Client (Patient Lounge TV & Phones)

    Note over Rec, Srv: Adding a New Patient
    Rec->>Srv: HTTP POST /api/patients { name: "Rahul" }
    Srv->>Srv: Generate Token (e.g., T001) & Add to queueState
    Srv-->>Rec: Respond HTTP 201 { token: "T001", name: "Rahul", status: "waiting" }
    Srv-->>Pat: Socket.io Emit ("queue-updated") [Full updated queue payload]
    Note over Pat: Lounge Board & Patient phones instantly re-render!

    Note over Rec, Srv: Calling Next Patient
    Rec->>Srv: HTTP POST /api/call-next
    Srv->>Srv: transition current to "done", change next to "in-consultation"
    Srv-->>Rec: Respond HTTP 200 { called: { token: "T001", ... } }
    Srv-->>Pat: Socket.io Emit ("queue-updated") [Advances live active token list]
    Srv-->>Pat: Socket.io Emit ("token-called") { token: "T001", name: "Rahul" }
    Note over Pat: Play audio chime "🔔 Now Serving: T001: Rahul" and flash indicator!
```

### ASCII Flowchart (Fallback)
```text
  [Receptionist Dashboard] ---------(POST /api/call-next)----------> [Express Server]
              ▲                                                           |
              |                                                           | (State Updated)
              | (Instant WebSocket Broadcast)                             ▼
      [All Connected Displays / Patient Phones] <-------- emit("queue-updated")
```

---

## 5. Screenshots
![Receptionist Monitor Page Placeholder](https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80)
*(Place your receptionist.jpg and lobby_waiting.jpg screenshots here for Wooble submission review)*

---

## 6. Live App Demo URL
[🔗 Live App Link](https://ais-dev-m7s5kvy6sudcwmg64eixue-1012550532878.asia-southeast1.run.app)

---

## 7. Author Portfolio
- **Lead Full-Stack Developer:** [Your Name]
- **Wooble Profile:** [🔗 My Wooble Hub](https://wooble.com/profile/your-portfolio)
